﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        pnlSignUp.Visible = true;
        btnLogin.Visible = false;
        btnSubmit.Visible = true;
        btnSignUp.Visible = false;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string fname, lname, username, email, country, password;

        fname = txtSignFirstName.Text;
        lname = txtSignLastName.Text;
        username = txtSignUsername.Text;
        email = txtSignEmail.Text;
        country = ddlCountry.SelectedValue;
        password = txtSignPass.Text;



          if (!passwordLengthCheck(password))
          {
              rfvSignPasswordLength.ErrorMessage = "Must be greater the 8 characters";

              rfvSignPasswordLength.IsValid = false;
          }
          if (!passwordRequirementCheck(password))
          {

              rfvSignPassword.ErrorMessage = "Password must contain 1 Upper case letter and 1 digit number";

              rfvSignPassword.IsValid = false;
          }
          if (!usernameCheck(username))
          {
              rfvUsername.ErrorMessage = "This username already exist";

              rfvUsername.IsValid = false;
          }


          if (Page.IsValid)
          {
              SqlConnection dB = new SqlConnection(SqlDataSource2.ConnectionString);
              SqlCommand cmd = new SqlCommand();
              cmd.CommandType = System.Data.CommandType.Text;
              cmd.CommandText = "INSERT UserInfo (User_FName, User_LName,User_UserName,User_Password,User_Country,User_Email) VALUES ('" + fname + "','" + lname + "','" + username + "','" + password + "','" + country + "','" + email + "')";
              cmd.Connection = dB;

              dB.Open();

              try
              {
                  cmd.ExecuteNonQuery();

              }
              catch
              {

              }
              finally
              {
                  dB.Close();
              }

              Response.Redirect("Login.aspx");
          }


      }

      protected void btnLogin_Click(object sender, EventArgs e)
      {
          Response.Redirect("Login.aspx");
      }

      protected bool passwordRequirementCheck(string password)
      {

          return password.Where(char.IsUpper).Count() >= 1 && password.Where(char.IsDigit).Count() >= 1;
      }
      protected bool passwordLengthCheck(string password)
      {

          return password.Length >= 8;
      }
      protected bool usernameCheck(string username)
      {
          SqlConnection dB = new SqlConnection(SqlDataSource2.ConnectionString);
          SqlCommand cmd = new SqlCommand("SELECT * FROM UserInfo", dB);
          SqlDataReader rdr = null;


          dB.Open();

          try
          {
              rdr = cmd.ExecuteReader();


              while (rdr.Read())
              {
                  string temp = (String)rdr["User_UserName"];

                  if (temp.Equals(username))
                  {
                      return false;
                  }
              }


          }
          catch
          {

          }
          finally
          {
              if (rdr != null)
              {
                  rdr.Close();
              }

              // close the connection
              if (dB != null)
              {
                  dB.Close();
              }

          }

          return true;
      }

      protected void btnAdmin_Click(object sender, EventArgs e)
      {
          Response.Redirect("Admin.aspx");
      }
    
}