﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class InternalMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string sessionType = (string)(Session["Type"]);
        if (sessionType == "AdminType")
        {
            btnEditUser.Visible = true;
        }
    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }

    protected void btnLogOut_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}
