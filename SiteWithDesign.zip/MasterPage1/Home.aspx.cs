﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string username = (string)Session["UserName"];


        Label1.Text = username;





    }
    protected void btnComment_Click(object sender, EventArgs e)
    {

        try
        {
            
            string constring = ConfigurationManager.ConnectionStrings["SocialMediaProjectConnectionString5"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Comments (Comment_Sender, Comment_Reciever, Comment, CommentDate) VALUES (@commentSender, @commentReceiver, @comment, @commentDate)", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@commentSender", Label1.Text);
                    cmd.Parameters.AddWithValue("@commentReceiver", Label1.Text);
                    cmd.Parameters.AddWithValue("@comment", txtComment.Text);
                    cmd.Parameters.AddWithValue("@commentDate", DateTime.Now.ToString());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();


                }

            }

            Response.Redirect("Home.aspx");


        }

        catch (Exception ex)
        {
            Response.Write(ex);
        }


    }
    protected void txtComment_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {

    }

    protected void btnFriend_Click(object sender, EventArgs e)
    {
        Response.Redirect("Friend.aspx");
    }
}