﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {


        if (IsValidUser(txtUsername.Text.Trim(), txtPasword.Text.Trim()))
        {
            Session["Username"] = txtUsername.Text;
            Session["type"] = "Usertype";
            Response.Redirect("Home.aspx");
        }
        else
        {
            // say Invalid Username or Password , please try again.
            rfvUsername.ErrorMessage = "oof. Invalid Email";
            rfvUsername.IsValid = false;
            rfvPassword.ErrorMessage = "oof. Invalid Password";
            rfvPassword.IsValid = false;

        }



    }
    protected void btnAdmin_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin.aspx");
    }

    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    private bool IsValidUser(string username, string passWord)
    {
        bool loginSuccessful = false;

        SqlConnection dB = new SqlConnection(SqlDataSource1.ConnectionString);
        SqlCommand sqlCommand = new SqlCommand("SELECT* FROM UserInfo WHERE User_UserName=@Username AND User_Password=@Password", dB);
        sqlCommand.Parameters.Add(new SqlParameter("@Username", username));
        sqlCommand.Parameters.Add(new SqlParameter("@Password", passWord));
        SqlDataReader rdr = null;

        dB.Open();

        try
        {
            rdr = sqlCommand.ExecuteReader();

            if (rdr.HasRows)
            {
                loginSuccessful = true;
                return loginSuccessful;
            }
        }
        catch
        {

        }
        finally
        {
            if (rdr != null)
            {
                rdr.Close();
            }

            // close the connection
            if (dB != null)
            {
                dB.Close();
            }

        }
        return loginSuccessful;
    }
}